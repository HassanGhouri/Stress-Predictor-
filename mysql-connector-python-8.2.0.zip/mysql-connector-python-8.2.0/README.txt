Copyright (c) 2009, 2023, Oracle and/or its affiliates.

This is a release of MySQL Connector/Python, Oracle's Python driver for MySQL.

License information can be found in the LICENSE.txt file.

This distribution may include materials developed by third parties. For license
and attribution notices for these materials, please refer to the LICENSE.txt file.

For more information on MySQL Connector/Python, visit
  https://dev.mysql.com/doc/dev/connector-python/

For additional downloads and the source of MySQL Connector/Python, visit
  http://dev.mysql.com/downloads/

MySQL Connector/Python is brought to you by the MySQL team at Oracle.
